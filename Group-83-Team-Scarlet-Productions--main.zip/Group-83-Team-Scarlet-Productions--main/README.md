Hi!
This is our website!
ENJOY OUR WEBSITE

Admin-Pathway:
Login by enter email with DailyGrindAdmin@gmail.com and password DailyGrindAdmin123!

Credits:
Product Pictures are made by Starbucks Websites.
Presentation slide: https://www.canva.com/design/DAGTsE7zds8/6Y4W_e-5oZkpZmqE2VWETQ/edit
